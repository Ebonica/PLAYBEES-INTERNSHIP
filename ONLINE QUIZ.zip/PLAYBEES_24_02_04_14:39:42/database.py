
4. Start the application:

