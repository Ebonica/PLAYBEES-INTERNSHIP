# Online Quiz and Certificate Generation

This is a web application for conducting online quizzes and generating certificates for the participants. The application allows administrators to upload quizzes with multiple-choice questions and topics. Participants can register, take the quiz, and view their results.

## Project Structure

The project has the following file structure:

- main.py: Entry point of the application
- templates/: Folder containing HTML templates
- static/: Folder containing static files (CSS, JS, images)
- models.py: Data models for the application
- admin_panel.py: Implementation of the admin panel
- quiz_portal.py: Implementation of the quiz portal
- database.py: Database operations
- utils.py: Utility functions
- requirements.txt: List of dependencies
- README.md: Project documentation

## Setup

1. Clone the repository:

