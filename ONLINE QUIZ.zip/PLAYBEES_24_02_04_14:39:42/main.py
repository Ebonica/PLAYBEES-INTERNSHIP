
5. Open the application in your web browser:

