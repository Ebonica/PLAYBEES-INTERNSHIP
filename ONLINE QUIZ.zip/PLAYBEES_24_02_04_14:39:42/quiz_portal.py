from models import User, Question, Result
from database import db
from utils import generate_random_questions, calculate_score, format_time

def register_user(name, contact, address):
    # Create a new User object and save it to the database
    pass

def participate_quiz(user_id, answers):
    # Retrieve the User object from the database
    # Retrieve 10 random questions from the database
    # Calculate the score based on the answers
    # Create a new Result object and save it to the database
    pass

def display_result(result_id):
    # Retrieve the Result object from the database
    # Return the Result object
    pass
